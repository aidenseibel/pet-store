CREATE DATABASE  IF NOT EXISTS `hamsterstore_test` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hamsterstore_test`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hamsterstore_test
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `listings`
--

DROP TABLE IF EXISTS `listings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `listings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `price` float unsigned NOT NULL,
  `vendor_id` int unsigned NOT NULL,
  `vendor_username` varchar(45) NOT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `weight` varchar(45) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idlistings_UNIQUE` (`id`),
  UNIQUE KEY `owneremail_UNIQUE` (`name`),
  KEY `vendor_username_idx` (`vendor_username`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listings`
--

LOCK TABLES `listings` WRITE;
/*!40000 ALTER TABLE `listings` DISABLE KEYS */;
INSERT INTO `listings` VALUES (11,'Alien Hamster 1',99.99,9,'hamster','https://files.oaiusercontent.com/file-RFgwVg69SI0cdSIU8hDdi5Z2?se=2024-05-07T05%3A29%3A57Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3De3fb185c-c0ac-4c5b-9726-c8f16388372b.webp&sig=DIz9dVWlLTIcHrl7bqhjQsuhoXp1mK9yoxns%2BlPbyoM%3D','15 ounces','Hamster from Mars'),(12,'Alien Hamster 2',13.99,8,'the_maria1','https://files.oaiusercontent.com/file-s8kLUJSSyHes5l4qGTTORc2Z?se=2024-05-07T05%3A31%3A05Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Dda90ad31-bba3-474b-b92c-1aa722eb6dc5.webp&sig=%2BTJnkSHcvdaEl7FukdcDNqPXXR9/jL%2BUlBKDuq9f2YA%3D','15 ounces','Hamster from Venus'),(13,'Alien Hamster 3',15.99,8,'the_maria1','https://files.oaiusercontent.com/file-hoZ1XWy7EdIvcNJP1o4YbAuz?se=2024-05-07T05%3A31%3A52Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Dae3c5923-9721-4b00-a9e8-724b6c4b793d.webp&sig=43OiePHZ9RVj08l16/vU41KIZa%2B3v6/cnXDvJdvYNAM%3D','21 ounces','Hamster from Pluto'),(14,'Alien Hamster 4',16.99,21,'prada','https://files.oaiusercontent.com/file-n0o5OQXe2wFxZAL5c54ERCDu?se=2024-05-07T05%3A32%3A34Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D15f64e66-91de-454c-afe4-e99590aab72a.webp&sig=TPcEY/XOUL8QRo0fxFY4UU0NjsV8K3U7ZlpH4nECeco%3D','15 ounces','Hamster from Jupiter'),(15,'Alien Hamster 5 ',17.99,8,'the_maria1','https://files.oaiusercontent.com/file-EoFI7acavaFl9e5vBb1RIphs?se=2024-05-07T05%3A33%3A07Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3D68ea274c-5d09-4c83-a5cf-f0b9e29f2ab8.webp&sig=xt9nNR8Lz27VdXL4uJEoA65ExczXc4gimzkCJLaWeg8%3D','17 ounces','Hamster from Mercury'),(16,'Alien Hamster 6 ',60.99,1,'mr_rains_concoctions','https://files.oaiusercontent.com/file-rfEBz46BpCnv4Q36vVBPBLC9?se=2024-05-07T05%3A33%3A34Z&sp=r&sv=2021-08-06&sr=b&rscc=max-age%3D31536000%2C%20immutable&rscd=attachment%3B%20filename%3Dad326f60-7bf0-4af1-a407-2f4793337713.webp&sig=1DJfVdUiQsslRQR5ebbwvo4v/mwU9tYgMgn1lD%2Bo%2BrQ%3D','20 ounces','Hamster from Saturn'),(17,'Alien Hamster 7',20.99,21,'the_maria1','https://images.nightcafe.studio/jobs/M6BFUzOF4vOJMUEHjNuE/M6BFUzOF4vOJMUEHjNuE--1--8ryg7.jpg?tr=w-640,c-at_max','29 ounces','Hamster from Uranus'),(18,'Alien Hamster 8',14.99,9,'hamster','https://images.playground.com/e9b96ab03c194b648b8dfe499127b8ae.jpeg','22 ounces','Hamster from Neptune');
/*!40000 ALTER TABLE `listings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-07  1:10:22
